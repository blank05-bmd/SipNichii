/* ==========================================================================
   Nichi Nichi — page behaviour. No libraries. Reads window.NICHI (config.js).
   ========================================================================== */
(function () {
  "use strict";

  var site = window.NICHI;
  var DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

  /* ---------- Helpers ---------- */
  function $(selector, root) { return (root || document).querySelector(selector); }
  function $$(selector, root) { return Array.prototype.slice.call((root || document).querySelectorAll(selector)); }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function icon(name) {
    return '<svg class="icon" aria-hidden="true"><use href="#i-' + name + '"/></svg>';
  }

  function toMinutes(time) {
    var p = time.split(":");
    return Number(p[0]) * 60 + Number(p[1]);
  }

  function formatTime(time) {
    var p = time.split(":").map(Number);
    var h = p[0], m = p[1];
    var suffix = h >= 12 && h < 24 ? "PM" : "AM";
    h = h % 12 || 12;
    return h + (m ? ":" + String(m).padStart(2, "0") : "") + " " + suffix;
  }

  /* ---------- Opening hours: current day + minutes, always in the café's timezone ---------- */
  function currentMoment() {
    var parts = new Intl.DateTimeFormat("en-US", {
      timeZone: site.timezone, weekday: "long", hour: "numeric", minute: "numeric", hourCycle: "h23"
    }).formatToParts(new Date());
    function get(type) { return parts.filter(function (p) { return p.type === type; })[0].value; }
    return {
      day: DAYS.indexOf(get("weekday")),
      minutes: (Number(get("hour")) % 24) * 60 + Number(get("minute"))
    };
  }

  function openStatus() {
    var now = currentMoment();
    var today = site.hours[now.day];
    var yesterday = site.hours[(now.day + 6) % 7];

    // Still open from yesterday's late shift (closes after midnight)?
    if (yesterday && toMinutes(yesterday[1]) <= toMinutes(yesterday[0]) && now.minutes < toMinutes(yesterday[1])) {
      return { open: true, until: yesterday[1] };
    }
    if (today) {
      var opens = toMinutes(today[0]), closes = toMinutes(today[1]);
      if (now.minutes >= opens && (closes <= opens || now.minutes < closes)) return { open: true, until: today[1] };
      if (now.minutes < opens) return { open: false, next: today[0], when: "" };
    }
    for (var i = 1; i <= 7; i++) {
      var d = (now.day + i) % 7;
      if (site.hours[d]) return { open: false, next: site.hours[d][0], when: i === 1 ? " tomorrow" : " " + DAYS[d] };
    }
    return { open: false };
  }

  /* ---------- Open / closed badge ---------- */
  function initStatusBadge() {
    var badge = $("#status-badge"), label = $("#status-label");
    function paint() {
      var s = openStatus();
      badge.dataset.state = s.open ? "open" : "closed";
      label.textContent = s.open
        ? "Open now · until " + formatTime(s.until)
        : s.next ? "Closed · opens " + formatTime(s.next) + s.when : "Closed";
    }
    paint();
    setInterval(paint, 60000);
  }

  /* ---------- Menu: segmented control + cross-fading panels ---------- */
  function initMenu() {
    var tablist = $("#menu-tabs"), panels = $("#menu-panels");
    var tabs = [];
    tablist.style.setProperty("--count", site.menu.length);

    site.menu.forEach(function (cat, i) {
      var tab = document.createElement("button");
      tab.type = "button";
      tab.id = "menu-tab-" + i;
      tab.className = "segmented__tab press";
      tab.textContent = cat.category;
      tab.tabIndex = i ? -1 : 0;
      tab.setAttribute("role", "tab");
      tab.setAttribute("aria-selected", String(i === 0));
      tab.setAttribute("aria-controls", "menu-panel-" + i);
      tablist.appendChild(tab);
      tabs.push(tab);

      var panel = document.createElement("div");
      panel.id = "menu-panel-" + i;
      panel.className = "menu__panel" + (i === 0 ? " is-active" : "");
      panel.setAttribute("role", "tabpanel");
      panel.setAttribute("aria-labelledby", tab.id);
      panel.innerHTML =
        '<ul class="menu__list">' +
        cat.items.map(function (item) {
          return '<li class="menu-item"><div><p class="menu-item__name">' + escapeHtml(item.name) + "</p>" +
            (item.desc ? '<p class="menu-item__desc">' + escapeHtml(item.desc) + "</p>" : "") +
            '</div><span class="menu-item__price">₱' + item.price + "</span></li>";
        }).join("") + "</ul>" +
        (cat.note ? '<p class="menu__note">' + escapeHtml(cat.note) + "</p>" : "");
      panels.appendChild(panel);
    });

    function select(index, moveFocus) {
      tabs.forEach(function (tab, j) {
        var on = j === index;
        tab.setAttribute("aria-selected", String(on));
        tab.tabIndex = on ? 0 : -1;
        panels.children[j].classList.toggle("is-active", on);
      });
      tablist.style.setProperty("--active", index);
      if (moveFocus) tabs[index].focus();
      tabs[index].scrollIntoView({ block: "nearest", inline: "nearest" });
    }

    tablist.addEventListener("click", function (e) {
      var i = tabs.indexOf(e.target.closest(".segmented__tab"));
      if (i > -1) select(i);
    });

    tablist.addEventListener("keydown", function (e) {
      var current = tabs.indexOf(document.activeElement), n = tabs.length;
      if (current < 0) return;
      var step = { ArrowRight: 1, ArrowLeft: -1, Home: -current, End: n - 1 - current }[e.key];
      if (step === undefined) return;
      e.preventDefault();
      select((current + step + n) % n, true);
    });
  }

  /* ---------- Hours table (Monday first, today highlighted) ---------- */
  function renderHours() {
    var today = currentMoment().day;
    $("#hours-body").innerHTML = [1, 2, 3, 4, 5, 6, 0].map(function (d) {
      var h = site.hours[d], isToday = d === today;
      return "<tr" + (isToday ? ' class="is-today" aria-current="date"' : "") + "><td>" + DAYS[d] +
        (isToday ? " · Today" : "") + "</td><td>" +
        (h ? formatTime(h[0]) + " – " + formatTime(h[1]) : "Closed") + "</td></tr>";
    }).join("");
  }

  /* ---------- Address, directions links, lazy map ---------- */
  function mapsQuery() {
    return encodeURIComponent([site.name, site.address.full].filter(Boolean).join(", "));
  }

  function initVisit() {
    $("#address").textContent = site.address.full || "Address coming soon";

    var isApple = /iP(hone|ad|od)/.test(navigator.userAgent) ||
      (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
    var coords = site.geo.lat ? site.geo.lat + "," + site.geo.lng : "";
    var q = mapsQuery();
    var url = isApple
      ? "https://maps.apple.com/?q=" + q + (coords ? "&ll=" + coords : "")
      : "https://www.google.com/maps/search/?api=1&query=" + (coords || q);

    $$("[data-maps-link]").forEach(function (a) {
      a.href = url; a.target = "_blank"; a.rel = "noopener";
    });

    var holder = $("#map");
    if (!site.mapEmbed) {
      $("#map-hint").textContent = "Tap “Open in Maps” for directions";
      return;
    }
    // Load the iframe only when the section is close to the viewport
    new IntersectionObserver(function (entries, observer) {
      if (!entries[0].isIntersecting) return;
      observer.disconnect();
      var frame = document.createElement("iframe");
      frame.src = site.mapEmbed;
      frame.title = "Map showing " + site.name + "'s location";
      frame.loading = "lazy";
      frame.referrerPolicy = "no-referrer-when-downgrade";
      frame.setAttribute("allowfullscreen", "");
      holder.appendChild(frame);
    }, { rootMargin: "600px 0px" }).observe(holder);
  }

  /* ---------- Reviews ---------- */
  function starsHtml(n) {
    var out = "";
    for (var i = 1; i <= 5; i++) {
      out += '<svg class="icon' + (i <= Math.round(n) ? " is-filled" : "") + '" aria-hidden="true"><use href="#i-star"/></svg>';
    }
    return '<div class="stars" role="img" aria-label="' + n + ' out of 5 stars">' + out + "</div>";
  }

  function renderReviews() {
    var r = site.rating;
    var link = r.url || "https://www.google.com/maps/search/?api=1&query=" + mapsQuery();

    var summary =
      '<article class="glass review-card review-card--summary">' +
      (r.value
        ? '<p class="review-card__score">' + r.value + "</p>" + starsHtml(r.value) +
          '<p class="muted">from ' + r.count + " Google reviews</p>"
        : '<p class="review-card__prompt">Been to Nichi Nichi?</p><p class="muted">We\'d love to hear how your visit went.</p>') +
      '<a class="btn btn--primary press" href="' + escapeHtml(link) + '" target="_blank" rel="noopener">' +
      (r.value ? "See all on Google" : "Review us on Google") + icon("out") + "</a></article>";

    var cards = site.reviews.map(function (rev) {
      return '<article class="glass review-card">' + starsHtml(rev.stars) +
        '<p class="review-card__text">“' + escapeHtml(rev.text) + '”</p>' +
        '<p class="review-card__name">' + escapeHtml(rev.name) + "</p></article>";
    }).join("");

    $("#reviews-rail").innerHTML = summary + cards;
  }

  /* ---------- Footer: socials + contact ---------- */
  function renderFooter() {
    var networks = {
      instagram: ["ig", "Instagram"], facebook: ["fb", "Facebook"],
      tiktok: ["tt", "TikTok"], other: ["link", "Website"]
    };
    $("#socials").innerHTML = Object.keys(networks).filter(function (k) { return site.socials[k]; }).map(function (k) {
      return '<a class="press" href="' + escapeHtml(site.socials[k]) + '" target="_blank" rel="noopener" aria-label="' +
        site.name + " on " + networks[k][1] + '">' + icon(networks[k][0]) + "</a>";
    }).join("");

    $("#contact").innerHTML =
      (site.phone ? '<a href="tel:' + escapeHtml(site.phone.replace(/\s/g, "")) + '">' + icon("phone") + escapeHtml(site.phone) + "</a>" : "") +
      (site.email ? '<a href="mailto:' + escapeHtml(site.email) + '">' + icon("mail") + escapeHtml(site.email) + "</a>" : "");

    $("#year").textContent = new Date().getFullYear();
  }

  /* ---------- Structured data for search engines ---------- */
  function injectStructuredData() {
    var base = location.href.split("#")[0];
    function abs(path) { return new URL(path, base).href; }

    var data = {
      "@context": "https://schema.org",
      "@type": "CafeOrCoffeeShop",
      name: site.name,
      description: site.description,
      url: base,
      image: site.seoImages.map(abs),
      logo: abs("images/logo.png"),
      servesCuisine: ["Coffee", "Matcha"],
      priceRange: "₱₱",
      menu: base + "#menu",
      hasMenu: base + "#menu",
      address: {
        "@type": "PostalAddress",
        streetAddress: site.address.street, addressLocality: site.address.city,
        addressRegion: site.address.region, postalCode: site.address.postal,
        addressCountry: site.address.country
      },
      openingHoursSpecification: site.hours.map(function (h, d) {
        return h && { "@type": "OpeningHoursSpecification", dayOfWeek: DAYS[d], opens: h[0], closes: h[1] };
      }).filter(Boolean),
      sameAs: Object.keys(site.socials).map(function (k) { return site.socials[k]; }).filter(Boolean)
    };
    if (site.phone) data.telephone = site.phone;
    if (site.email) data.email = site.email;
    if (site.geo.lat) data.geo = { "@type": "GeoCoordinates", latitude: site.geo.lat, longitude: site.geo.lng };
    if (site.rating.value) data.aggregateRating = { "@type": "AggregateRating", ratingValue: site.rating.value, reviewCount: site.rating.count, bestRating: 5 };

    var tag = document.createElement("script");
    tag.type = "application/ld+json";
    tag.textContent = JSON.stringify(data);
    document.head.appendChild(tag);
  }

  /* ---------- Scroll behaviour ---------- */
  function initScroll() {
    // Header turns glassy once the page moves (rAF-throttled)
    var header = $("#site-header"), queued = false;
    function update() { header.classList.toggle("is-scrolled", window.scrollY > 8); queued = false; }
    window.addEventListener("scroll", function () {
      if (!queued) { queued = true; requestAnimationFrame(update); }
    }, { passive: true });
    update();

    // Reveal blocks once
    var reveal = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { e.target.classList.add("is-visible"); reveal.unobserve(e.target); }
      });
    }, { rootMargin: "0px 0px -8% 0px" });
    $$(".reveal").forEach(function (el) { reveal.observe(el); });

    // Tab bar follows the section in view
    var links = $$(".tab-bar a");
    var spy = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (!e.isIntersecting) return;
        links.forEach(function (a) { a.setAttribute("aria-current", String(a.dataset.section === e.target.id)); });
      });
    }, { rootMargin: "-45% 0px -50% 0px" });
    ["home", "menu", "reviews", "visit"].forEach(function (id) { spy.observe(document.getElementById(id)); });
  }

  /* ---------- Boot ---------- */
  initStatusBadge();
  initMenu();
  renderHours();
  initVisit();
  renderReviews();
  renderFooter();
  injectStructuredData();
  initScroll();
})();
