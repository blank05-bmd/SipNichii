/* ==========================================================================
   Nichi Nichi — site content. Edit this file; no need to touch the layout.
   ========================================================================== */
window.NICHI = {
  name: "Nichi Nichi",
  description: "A cosy blue-and-cream café for coffee, matcha and fruit drinks.",

  address: {
    full: "",            // e.g. "123 Sample St., Barangay X, Quezon City, Metro Manila"
    street: "",
    city: "",
    region: "Metro Manila",
    postal: "",
    country: "PH"
  },
  geo: { lat: null, lng: null },   // e.g. { lat: 14.6, lng: 121.0 }
  mapEmbed: "",                    // Google Maps > Share > Embed a map > copy the src="..." URL
  phone: "",                       // e.g. "+63 917 000 0000"
  email: "",

  socials: {                       // leave "" to hide an icon
    instagram: "https://www.instagram.com/sipnichi/",
    facebook: "https://www.facebook.com/profile.php?id=61579303052638",
    tiktok: "https://www.tiktok.com/@sipnichi",
    other: ""
  },

  // Opening hours in Manila time. Index 0 = Sunday. Use null for a closed day.
  // A close time earlier than the open time means "past midnight".
  timezone: "Asia/Manila",
  hours: [
    ["12:00", "23:00"], ["12:00", "23:00"], ["12:00", "23:00"], ["12:00", "23:00"],
    ["12:00", "23:00"], ["12:00", "23:00"], ["12:00", "23:00"]
  ],

  // Google rating — fill in from your Google Business profile
  rating: { value: null, count: null, url: "" },   // e.g. { value: 4.8, count: 320, url: "https://g.page/r/..." }

  // Real Google reviews only, copied with permission. Example:
  // { text: "Best sea salt latte in the area.", name: "Ana R.", stars: 5 }
  reviews: [],

  // Photos used for structured data (search engines). Paths relative to index.html.
  seoImages: ["images/storefront.jpg", "images/counter.jpg", "images/window-seats.jpg"],

  menu: [
    {
      category: "Coffee",
      items: [
        { name: "Americano", price: 115, desc: "Espresso lengthened with water." },
        { name: "Cafe Latte", price: 125, desc: "Espresso and steamed milk." },
        { name: "Spanish Latte", price: 125, desc: "Latte sweetened with condensed milk." },
        { name: "Nichicano", price: 135, desc: "Our house signature." },
        { name: "Vanilla Latte", price: 145, desc: "Latte with vanilla." },
        { name: "Toffee Nut Latte", price: 145, desc: "Latte with toffee nut." },
        { name: "Salted Caramel Latte", price: 155, desc: "Latte with salted caramel." },
        { name: "Hazelnut Latte", price: 155, desc: "Latte with hazelnut." },
        { name: "Dark Mocha", price: 155, desc: "Espresso, dark chocolate and milk." },
        { name: "White Chocolate Mocha", price: 155, desc: "Espresso, white chocolate and milk." },
        { name: "Sea Salt Latte", price: 155, desc: "Latte with sea salt cream." },
        { name: "Caramel Macchiato", price: 155, desc: "Milk, espresso and caramel." },
        { name: "Biscoff Latte", price: 175, desc: "Latte with Biscoff." }
      ]
    },
    {
      category: "Non-Coffee",
      items: [
        { name: "Strawberry Milk", price: 125, desc: "Milk with strawberry." },
        { name: "Blueberry Milk", price: 125, desc: "Milk with blueberry." },
        { name: "Chocolate Milk", price: 125, desc: "Milk with chocolate." },
        { name: "Ube Milk", price: 125, desc: "Milk with ube." }
      ]
    },
    {
      category: "Spirits",
      items: [
        { name: "Strawberry", price: 85 },
        { name: "Green Apple", price: 85 },
        { name: "Lychee", price: 85 },
        { name: "Passionfruit", price: 85 },
        { name: "Cherry Lime", price: 95 },
        { name: "Cherry Lime & Raspberry", price: 95 }
      ]
    },
    {
      category: "Matcha",
      note: "Choose your matcha strength: Level 1 (default) free · Level 2 intense +₱50 · Level 3 extreme +₱90",
      items: [
        { name: "Matcha Latte", price: 195, desc: "Matcha and milk." },
        { name: "Earl Grey Matcha", price: 205, desc: "Matcha latte with Earl Grey." },
        { name: "Sea Salt Matcha", price: 205, desc: "Matcha latte with sea salt cream." },
        { name: "Ube Matcha", price: 205, desc: "Matcha latte with ube." },
        { name: "Matcha Ichigo", price: 215, desc: "Matcha latte with strawberry." },
        { name: "Hojicha", price: 175, desc: "Roasted green tea latte." }
      ]
    },
    {
      category: "Extras",
      items: [
        { name: "Espresso", price: 30, desc: "Extra shot." },
        { name: "Sauce", price: 35 },
        { name: "Syrup", price: 45 },
        { name: "Jam", price: 30 },
        { name: "Sub Oat", price: 50, desc: "Swap to oat milk." },
        { name: "Blue Agave", price: 50 },
        { name: "Sea Salt Cream", price: 50 }
      ]
    }
  ]
};
